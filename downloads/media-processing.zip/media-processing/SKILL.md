---
name: media-processing
description: 当用户提供或提及视频/音频文件处理需求时调用——转录、转写、提取内容、生成字幕。触发词："视频""音频""转录""转写""字幕""帮我看这个视频/音频""提取视频内容"。规则：优先用 ffmpeg + whisper 处理。
---

# 视频音频优先处理规则

**核心规则：碰到视频/音频文件，优先级最高，直接用 ffmpeg + whisper 处理，不要绕弯路。**

## 触发条件
用户提到：视频文件(.mp4/.avi/.mov/.mkv)、音频文件(.mp3/.wav/.m4a/.flac)、"帮我看一下这个视频""转录这个音频"、任何音视频处理需求。

## 处理流程（严格按顺序）
1. **第一步 Whisper 转录**：写 Python 脚本调用 whisper（small 模型，中文效果好），自动设置 ffmpeg 路径。
2. **第二步 读取转录结果**：用 Read 工具读转录后的 txt，理解内容后回应用户。
3. **第三步 不要先试其他方式**：不要先用 Read 读视频（读不了）、不要先写 OpenCV 提取帧（除非用户明确要截图）。直接上 Whisper。

## 标准脚本模板
```python
import os
import whisper
import imageio_ffmpeg

ffmpeg_exe = imageio_ffmpeg.get_ffmpeg_exe()
os.environ["PATH"] = os.path.dirname(ffmpeg_exe) + os.pathsep + os.environ["PATH"]

input_path = r"路径/to/your/video.mp4"
output_path = r"路径/to/output.txt"

model = whisper.load_model("small")
result = model.transcribe(input_path, language="zh")
with open(output_path, "w", encoding="utf-8") as f:
    f.write(result["text"])
print(f"已保存到: {output_path}")
```

## 环境说明
- 原始规范基于 Windows + Python 3.13 + `imageio-ffmpeg`/`openai-whisper`（已验证，勿重复安装 700MB+）。
- **本机为 macOS**：先 `python3 -c "import imageio_ffmpeg, whisper; print('ok')"` 验证是否已安装；未安装则用 `pip install imageio-ffmpeg openai-whisper`。macOS 上 ffmpeg 通常通过 `imageio_ffmpeg.get_ffmpeg_exe()` 获取，不在系统 PATH。
- 详细安装指南见 `references/视频音频优先处理规则.md`。

**记住：视频音频文件 → 直接 Whisper！不要绕弯路！**
